package pl.mrteflon.heartfactions.listener;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class ProtectionListener implements Listener {

    private final HeartFactionsPlugin plugin;
    private final Map<UUID, BossBar> playerBossBars = new HashMap<>();

    public ProtectionListener(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean canBuild(Player player, Block block) {
        if (!plugin.getConfig().getBoolean("protection.protect-blocks", true)) return true;

        FactionManager manager = plugin.getFactionManager();
        Faction owner = manager.getFactionAt(block.getChunk());
        if (owner == null) return true;

        return owner.isMember(player.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(block.getChunk());

        if (faction != null) {
            Location heartLoc = faction.getHeartLocation();
            if (heartLoc != null) {
                int cx = heartLoc.getBlockX();
                int cy = heartLoc.getBlockY();
                int cz = heartLoc.getBlockZ();

                double dist = Math.sqrt(Math.pow(block.getX() - cx, 2) + Math.pow(block.getY() - cy, 2) + Math.pow(block.getZ() - cz, 2));
                if (dist <= HeartStructure.RADIUS) {
                    event.setDropItems(false);
                }
            }

            if (!canBuild(event.getPlayer(), block)) {
                event.setCancelled(true);
                Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie możesz tu niszczyć bloków.");
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        ItemStack item = event.getItemInHand();

        // Stawianie C4
        if (item.getType() == Material.TNT && item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null && meta.hasDisplayName() && meta.getDisplayName().equals("§c§lC4")) {
                Block block = event.getBlockPlaced();
                Location loc = block.getLocation().add(0.5, 0, 0.5);

                block.setType(Material.AIR);
                org.bukkit.entity.TNTPrimed tnt = (org.bukkit.entity.TNTPrimed) block.getWorld().spawnEntity(loc, EntityType.TNT);
                tnt.setFuseTicks(40); // 2 sekundy
                tnt.setCustomName("§c§lC4");
                tnt.setCustomNameVisible(true);

                Msg.send(plugin, event.getPlayer(), "&cPostawiono &c&lC4&c! Wybuch za 2 sekundy!");
                return;
            }
        }

        if (!canBuild(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie możesz tu stawiać bloków.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        // Wybuch C4 niszczący osłonę
        if (event.getEntityType() == EntityType.TNT && "§c§lC4".equals(event.getEntity().getCustomName())) {
            Location loc = event.getLocation();
            int radius = 4;

            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        Block b = loc.clone().add(x, y, z).getBlock();
                        if (b.getType() != Material.AIR && b.getType() != Material.BEDROCK) {
                            if (loc.distance(b.getLocation()) <= radius) {
                                b.setType(Material.AIR);
                            }
                        }
                    }
                }
            }
            return;
        }

        if (!plugin.getConfig().getBoolean("protection.protect-explosions", true)) return;

        FactionManager manager = plugin.getFactionManager();
        Iterator<Block> it = event.blockList().iterator();
        while (it.hasNext()) {
            Block block = it.next();
            if (manager.getFactionAt(block.getChunk()) != null) {
                it.remove();
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!plugin.getConfig().getBoolean("protection.protect-containers", true)) return;

        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!(block.getState() instanceof InventoryHolder)) return;

        if (!canBuild(event.getPlayer(), block)) {
            event.setCancelled(true);
            Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie masz dostępu do tego kontenera.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (event.getEntityType() != EntityType.END_CRYSTAL) return;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getEntity().getLocation().getChunk());

        if (faction != null) {
            Location heartLoc = faction.getHeartLocation();

            if (heartLoc != null && heartLoc.distance(event.getEntity().getLocation()) < 3.0) {
                if (event.getDamager() instanceof Player player) {
                    if (faction.isMember(player.getUniqueId())) {
                        Msg.send(plugin, player, "&cNie możesz zniszczyć własnego Serca!");
                        event.setCancelled(true);
                        return;
                    }

                    event.setCancelled(true);

                    int currentLives = faction.getCurrentHeartLives();
                    if (currentLives > 1) {
                        faction.setCurrentHeartLives(currentLives - 1);
                        manager.save();
                        Msg.send(plugin, player, "&eAtakujesz Serce! Pozostałe życia Serca: &c" + (currentLives - 1) + "/" + faction.getLevel());
                        return;
                    }

                    int currentLevel = faction.getLevel();

                    if (currentLevel > 1) {
                        int newLevel = currentLevel - 1;
                        faction.setLevel(newLevel);
                        faction.setUpgradeLockedUntil(System.currentTimeMillis() + 30L * 60 * 1000);
                        manager.save();

                        HeartStructure.removeStructure(heartLoc);
                        event.getEntity().remove();

                        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cSerce frakcji §l" + faction.getName() +
                                " §czostało zniszczone przez §l" + player.getName() + "§c! Poziom frakcji spadł do §e" + newLevel +
                                "§c. Serce odrodzi się za §l10 minut§c, a ulepszanie będzie zablokowane przez §l30 minut§c.");

                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                Faction checkF = manager.getByName(faction.getName());
                                if (checkF != null && checkF.getHeartLocation() != null) {
                                    HeartStructure.generateStructure(checkF.getHeartLocation(), checkF.getLevel());
                                    Bukkit.broadcastMessage("§8[§bFrakcje§8] §aSerce frakcji §l" + checkF.getName() + " §anowu odrodziło się z nową obudową!");
                                }
                            }
                        }.runTaskLater(plugin, 12000L);

                    } else {
                        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cFrakcja §l" + faction.getName() + " §czostała zniszczona przez §l" + player.getName() + "§c!");

                        HeartStructure.removeStructure(heartLoc);
                        event.getEntity().remove();
                        manager.disbandFaction(faction);
                    }
                } else {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getTo().getChunk());

        if (faction != null) {
            BossBar bar = playerBossBars.computeIfAbsent(player.getUniqueId(), k -> {
                BossBar newBar = Bukkit.createBossBar("", BarColor.RED, BarStyle.SOLID);
                newBar.addPlayer(player);
                return newBar;
            });
            bar.setTitle("§cTeren Frakcji: §l" + faction.getName() + " §7(Poziom " + faction.getLevel() + ")");
            bar.setVisible(true);
        } else {
            BossBar bar = playerBossBars.get(player.getUniqueId());
            if (bar != null) {
                bar.setVisible(false);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        BossBar bar = playerBossBars.remove(event.getPlayer().getUniqueId());
        if (bar != null) {
            bar.removeAll();
        }
    }
}