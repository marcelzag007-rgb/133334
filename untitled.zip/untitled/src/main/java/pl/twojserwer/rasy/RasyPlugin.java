package pl.twojserwer.rasy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class RasyPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private NamespacedKey raceKey;
    private final Random random = new Random();

    @Override
    public void onEnable() {
        this.raceKey = new NamespacedKey(this, "gracz_rasa");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("rasa") != null) {
            getCommand("rasa").setExecutor(this);
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    applyRaceEffects(player);
                }
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Ta komenda jest tylko dla graczy!");
            return true;
        }

        Player player = (Player) sender;

        if (hasChosenRace(player)) {
            player.sendMessage(ChatColor.RED + "Wybrałeś już swoją rasę! Nie możesz jej zmienić.");
            return true;
        }

        openRaceMenu(player);
        return true;
    }

    private void openRaceMenu(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, ChatColor.BLUE + "Wybór Rasy");

        ItemStack glass = createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) {
            gui.setItem(i, glass);
        }

        gui.setItem(9, createGuiItem(Material.LEATHER_HELMET, "&aGoblin",
                "&7Wzrost: &f1.5 bloku", "&7Szybkość: &fSpeed I", "&7Zdrowie: &c6 Serc"));

        gui.setItem(10, createGuiItem(Material.NETHERITE_CHESTPLATE, "&cOrk",
                "&7Wzrost: &f3 bloki", "&7Szybkość: &fSlowness I", "&7Zdrowie: &c15 Serc", "&7Siła: &fStrength I"));

        gui.setItem(11, createGuiItem(Material.IRON_PICKAXE, "&eKrasnolud",
                "&7Wzrost: &f1.25 bloku", "&7Szybkość: &fSlowness I", "&7Zdrowie: &c12 Serc", "&7Efekt: &fHaste II"));

        gui.setItem(12, createGuiItem(Material.REDSTONE, "&4Wampir",
                "&7Wzrost: &f2 bloki", "&eDzień: &7Pali się, Slowness II, Weakness II",
                "&nNoc:&7 Speed II, Strength I", "&7Specjalne: &f20% szans na leczenie po ciosie"));

        gui.setItem(13, createGuiItem(Material.FEATHER, "&dWróżka",
                "&7Wzrost: &f0.5 bloku", "&7Szybkość: &fSpeed II", "&7Zdrowie: &c3 Serca", "&7Specjalne: &fLatanie, Brak fall damage"));

        gui.setItem(14, createGuiItem(Material.BOW, "&1Mroczny Elf",
                "&7Wzrost: &f2 bloki", "&nNoc:&7 Speed I, Strength I"));

        gui.setItem(15, createGuiItem(Material.WOODEN_HOE, "&6Faun",
                "&7Wzrost: &f2.5 bloku", "&7Szybkość: &fSpeed II", "&7Skok: &fJump Boost II", "&7Zdrowie: &c8 Serc"));

        gui.setItem(16, createGuiItem(Material.SLIME_BALL, "&2Żaboczłek",
                "&7Wzrost: &f1.5 bloku", "&7Skok: &fJump Boost II", "&7Oddychanie: &fOddychanie pod wodą", "&7Osłabienie: &fWeakness I"));

        gui.setItem(17, createGuiItem(Material.GOLDEN_PICKAXE, "&eKobold",
                "&7Wzrost: &f1.25 bloku", "&7Szybkość: &fSpeed I", "&7Ochrona: &fResistance I", "&7Osłabienie: &fWeakness I"));

        player.openInventory(gui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals(ChatColor.BLUE + "Wybór Rasy")) return;
        event.setCancelled(true);

        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;

        Player player = (Player) event.getWhoClicked();

        if (hasChosenRace(player)) {
            player.sendMessage(ChatColor.RED + "Wybrałeś już swoją rasę!");
            player.closeInventory();
            return;
        }

        String race = null;
        switch (event.getSlot()) {
            case 9: race = "goblin"; break;
            case 10: race = "ork"; break;
            case 11: race = "krasnolud"; break;
            case 12: race = "wampir"; break;
            case 13: race = "wrozka"; break;
            case 14: race = "mroczny_elf"; break;
            case 15: race = "faun"; break;
            case 16: race = "zaboczlek"; break;
            case 17: race = "kobold"; break;
        }

        if (race != null) {
            setPlayerRace(player, race);
            player.sendMessage(ChatColor.GREEN + "Pomyślnie wybrano rasę: " + ChatColor.GOLD + race.toUpperCase() + "!");
            player.closeInventory();
            applyRaceStatsAndSize(player, race);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player player = (Player) event.getDamager();
            if ("wampir".equals(getRace(player))) {
                if (random.nextInt(100) < 20) {
                    double currentHealth = player.getHealth();
                    AttributeInstance maxHealthAttr = getMaxHealthAttribute(player);
                    double maxHealth = (maxHealthAttr != null) ? maxHealthAttr.getValue() : 20.0;

                    player.setHealth(Math.min(maxHealth, currentHealth + 1.0));
                    player.sendMessage(ChatColor.DARK_RED + " Wyssałeś krew! (+0.5 serca)");
                }
            }
        }
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            Player player = (Player) event.getEntity();
            if ("wrozka".equals(getRace(player))) {
                event.setCancelled(true);
            }
        }
    }

    private void applyRaceStatsAndSize(Player player, String race) {
        AttributeInstance healthAttr = getMaxHealthAttribute(player);

        double maxHealth = 20.0;
        double scale = 1.0;
        boolean canFly = false;

        switch (race) {
            case "goblin":
                maxHealth = 12.0;
                scale = 0.75;
                break;
            case "ork":
                maxHealth = 30.0;
                scale = 1.5;
                break;
            case "krasnolud":
                maxHealth = 24.0;
                scale = 0.625; // Odpowiada wysokości ~1.25 bloku
                break;
            case "wampir":
                maxHealth = 20.0;
                break;
            case "wrozka":
                maxHealth = 6.0; // 3 Serca
                scale = 0.25;
                canFly = true;
                break;
            case "faun":
                maxHealth = 16.0;
                scale = 1.25;
                break;
            case "kobold":
                maxHealth = 14.0;
                scale = 0.625; // Odpowiada wysokości ~1.25 bloku
                break;
        }

        if (healthAttr != null) {
            healthAttr.setBaseValue(maxHealth);
            if (player.getHealth() > maxHealth) player.setHealth(maxHealth);
        }

        setScaleAttribute(player, scale);
        player.setAllowFlight(canFly);
    }

    private void applyRaceEffects(Player player) {
        String race = getRace(player);
        if (race == null) return;

        boolean isDay = player.getWorld().getTime() < 12300;

        switch (race) {
            case "goblin":
                giveEffect(player, "SPEED", 0);
                break;
            case "ork":
                giveEffect(player, "SLOWNESS", 0);
                giveEffect(player, "STRENGTH", 0);
                break;
            case "krasnolud":
                giveEffect(player, "SLOWNESS", 0);
                giveEffect(player, "HASTE", 1);
                break;
            case "wampir":
                if (isDay && player.getLocation().getBlock().getLightFromSky() > 10) {
                    player.setFireTicks(40);
                    giveEffect(player, "SLOWNESS", 1);
                    giveEffect(player, "WEAKNESS", 1);
                } else {
                    giveEffect(player, "SPEED", 1);
                    giveEffect(player, "STRENGTH", 0);
                }
                break;
            case "wrozka":
                giveEffect(player, "SPEED", 1);
                break;
            case "mroczny_elf":
                if (!isDay) {
                    giveEffect(player, "SPEED", 0);
                    giveEffect(player, "STRENGTH", 0);
                }
                break;
            case "faun":
                giveEffect(player, "SPEED", 1);
                giveEffect(player, "JUMP_BOOST", 1); // Jump Boost II
                break;
            case "zaboczlek":
                giveEffect(player, "JUMP_BOOST", 1); // Jump Boost II
                giveEffect(player, "WATER_BREATHING", 0); // Oddychanie pod wodą
                giveEffect(player, "WEAKNESS", 0);
                break;
            case "kobold":
                giveEffect(player, "SPEED", 0);
                giveEffect(player, "RESISTANCE", 0);
                giveEffect(player, "WEAKNESS", 0);
                break;
        }
    }

    private AttributeInstance getMaxHealthAttribute(Player player) {
        try {
            return player.getAttribute(Attribute.valueOf("GENERIC_MAX_HEALTH"));
        } catch (Throwable t) {
            try {
                return player.getAttribute(Attribute.valueOf("MAX_HEALTH"));
            } catch (Throwable ignored) {
                return null;
            }
        }
    }

    private void setScaleAttribute(Player player, double scale) {
        try {
            AttributeInstance scaleAttr = player.getAttribute(Attribute.valueOf("GENERIC_SCALE"));
            if (scaleAttr != null) {
                scaleAttr.setBaseValue(scale);
            }
        } catch (Throwable ignored) {
            // Wersje serwera nieobsługujące atrybutu GENERIC_SCALE zignorują skalowanie bez zgłaszania błędów
        }
    }

    private void giveEffect(Player player, String effectName, int amplifier) {
        PotionEffectType type = PotionEffectType.getByName(effectName);
        if (type == null) {
            if ("SLOWNESS".equals(effectName)) type = PotionEffectType.getByName("SLOW");
            else if ("HASTE".equals(effectName)) type = PotionEffectType.getByName("FAST_DIGGING");
            else if ("JUMP_BOOST".equals(effectName)) type = PotionEffectType.getByName("JUMP");
            else if ("RESISTANCE".equals(effectName)) type = PotionEffectType.getByName("DAMAGE_RESISTANCE");
            else if ("STRENGTH".equals(effectName)) type = PotionEffectType.getByName("INCREASE_DAMAGE");
            else if ("WATER_BREATHING".equals(effectName)) type = PotionEffectType.getByName("WATER_BREATHING");
        }
        if (type != null) {
            player.addPotionEffect(new PotionEffect(type, 40, amplifier, false, false));
        }
    }

    private boolean hasChosenRace(Player player) {
        return getRace(player) != null;
    }

    private void setPlayerRace(Player player, String race) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        pdc.set(raceKey, PersistentDataType.STRING, race);
    }

    private String getRace(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        return pdc.get(raceKey, PersistentDataType.STRING);
    }

    private ItemStack createGuiItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            List<String> list = new ArrayList<>();
            for (String l : lore) {
                list.add(ChatColor.translateAlternateColorCodes('&', l));
            }
            meta.setLore(list);
            item.setItemMeta(meta);
        }
        return item;
    }
}