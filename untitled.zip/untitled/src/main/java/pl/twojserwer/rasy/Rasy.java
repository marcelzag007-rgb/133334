package pl.twojserwer.rasy;

import org.bukkit.plugin.java.JavaPlugin;

public final class Rasy extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
