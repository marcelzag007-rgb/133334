package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class DenyCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public DenyCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /odrzuc <nazwa_frakcji>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByName(args[0]);

        if (faction == null || !manager.hasInvite(player.getUniqueId(), faction)) {
            Msg.send(plugin, player, "&cNie masz zaproszenia od tej frakcji.");
            return true;
        }

        manager.clearInvite(player.getUniqueId(), faction);
        Msg.send(plugin, player, "&cOdrzucono zaproszenie od frakcji &f" + faction.getName() + "&c.");
        return true;
    }
}