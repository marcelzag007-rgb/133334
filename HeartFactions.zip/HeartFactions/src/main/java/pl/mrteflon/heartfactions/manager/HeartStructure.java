package pl.mrteflon.heartfactions.manager;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

public class HeartStructure {

    public static Material getMaterialForLevel(int level) {
        return switch (level) {
            case 1 -> Material.STONE_BRICKS;
            case 2 -> Material.OBSIDIAN;
            case 3 -> Material.CRYING_OBSIDIAN;
            case 4 -> Material.ANCIENT_DEBRIS;
            default -> Material.NETHERITE_BLOCK;
        };
    }

    public static void generateStructure(Location centerLoc, int level) {
        World world = centerLoc.getWorld();
        if (world == null) return;

        // Serce (i środek kuli) jest dokładnie tam, gdzie stał gracz w chwili /stworz -
        // żadnego wymuszania Y=0, bierzemy realną lokalizację.
        int cx = centerLoc.getBlockX();
        int cy = centerLoc.getBlockY();
        int cz = centerLoc.getBlockZ();

        int radius = 4; // Promień kuli

        Material wallMat = getMaterialForLevel(level);

        // Generowanie pustej kuli wyśrodkowanej na graczu
        for (int x = cx - radius; x <= cx + radius; x++) {
            for (int y = cy - radius; y <= cy + radius; y++) {
                for (int z = cz - radius; z <= cz + radius; z++) {
                    // Wyliczanie odległości danego bloku od środka kuli
                    double distance = Math.sqrt(Math.pow(x - cx, 2) + Math.pow(y - cy, 2) + Math.pow(z - cz, 2));

                    Block block = world.getBlockAt(x, y, z);

                    // Jeśli blok znajduje się w promieniu kuli
                    if (distance <= radius) {
                        // Zewnętrzna powłoka kuli (grubość ok. 1 bloku)
                        if (distance >= radius - 1.2) {
                            block.setType(wallMat);
                        } else {
                            // Środek kuli to powietrze
                            block.setType(Material.AIR);
                        }
                    }
                }
            }
        }

        // Postument dokładnie pod stopami gracza, by kryształ miał na czym "stać"
        world.getBlockAt(cx, cy - 1, cz).setType(Material.BEDROCK);

        // Kryształ spawnuje się dokładnie w miejscu, w którym stał gracz
        Location crystalLoc = new Location(world, cx + 0.5, cy, cz + 0.5);

        // Usuwanie ewentualnego starego kryształu (podczas ulepszania frakcji)
        for (Entity e : world.getNearbyEntities(crystalLoc, 3.0, 3.0, 3.0)) {
            if (e.getType() == EntityType.END_CRYSTAL) {
                e.remove();
            }
        }

        // Tworzenie nowego kryształu
        EnderCrystal crystal = (EnderCrystal) world.spawnEntity(crystalLoc, EntityType.END_CRYSTAL);
        crystal.setShowingBottom(true);
        crystal.setCustomName("§b§lSerce Frakcji");
        crystal.setCustomNameVisible(true);
    }
}