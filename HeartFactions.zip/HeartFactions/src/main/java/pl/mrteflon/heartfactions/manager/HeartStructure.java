package pl.mrteflon.heartfactions.manager;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

public class HeartStructure {

    public static final int RADIUS = 3;

    public static Material getMaterialForLevel(int level) {
        return switch (level) {
            case 1 -> Material.STONE_BRICKS;
            case 2 -> Material.COPPER_BLOCK;
            case 3 -> Material.IRON_BLOCK;
            case 4 -> Material.GOLD_BLOCK;
            case 5 -> Material.OBSIDIAN;
            case 6 -> Material.CRYING_OBSIDIAN;
            case 7 -> Material.DIAMOND_BLOCK;
            case 8 -> Material.EMERALD_BLOCK;
            case 9 -> Material.ANCIENT_DEBRIS;
            case 10 -> Material.NETHERITE_BLOCK;
            default -> Material.NETHERITE_BLOCK;
        };
    }

    public static void generateStructure(Location center, int level) {
        if (center == null || center.getWorld() == null) return;
        World world = center.getWorld();
        Material mat = getMaterialForLevel(level);

        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        // Generowanie kuli / osłony wokół centrum Serca
        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int y = -RADIUS; y <= RADIUS; y++) {
                for (int z = -RADIUS; z <= RADIUS; z++) {
                    double dist = Math.sqrt(x * x + y * y + z * z);
                    if (dist >= RADIUS - 0.7 && dist <= RADIUS + 0.5) {
                        Block b = world.getBlockAt(cx + x, cy + y, cz + z);
                        b.setType(mat);
                    }
                }
            }
        }

        // Wyszyszczenie wnętrza kuli
        for (int x = -(RADIUS - 1); x <= (RADIUS - 1); x++) {
            for (int y = -(RADIUS - 1); y <= (RADIUS - 1); y++) {
                for (int z = -(RADIUS - 1); z <= (RADIUS - 1); z++) {
                    double dist = Math.sqrt(x * x + y * y + z * z);
                    if (dist < RADIUS - 0.7) {
                        Block b = world.getBlockAt(cx + x, cy + y, cz + z);
                        b.setType(Material.AIR);
                    }
                }
            }
        }

        // Respawn kryształu w środku
        Location crystalLoc = center.clone().add(0.5, 0, 0.5);
        boolean exists = false;
        for (Entity e : world.getNearbyEntities(crystalLoc, 1.5, 1.5, 1.5)) {
            if (e.getType() == EntityType.END_CRYSTAL) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            world.spawnEntity(crystalLoc, EntityType.END_CRYSTAL);
        }
    }

    public static void removeStructure(Location center) {
        if (center == null || center.getWorld() == null) return;
        World world = center.getWorld();

        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int y = -RADIUS; y <= RADIUS; y++) {
                for (int z = -RADIUS; z <= RADIUS; z++) {
                    Block b = world.getBlockAt(cx + x, cy + y, cz + z);
                    b.setType(Material.AIR);
                }
            }
        }

        Location crystalLoc = center.clone().add(0.5, 0, 0.5);
        for (Entity e : world.getNearbyEntities(crystalLoc, 2, 2, 2)) {
            if (e.getType() == EntityType.END_CRYSTAL) {
                e.remove();
            }
        }
    }
}