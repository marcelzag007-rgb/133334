package pl.mrteflon.heartfactions.model;

public enum Rank {

    CZLONEK("Członek"),
    OFICER("Oficer"),
    ZASTEPCA("Zastępca Lidera"),
    LIDER("Lider");

    private final String displayName;

    Rank(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static Rank highestPromotable() {
        return ZASTEPCA;
    }

    public Rank next() {
        int idx = this.ordinal() + 1;
        Rank[] values = values();
        return idx < values.length ? values[idx] : this;
    }

    public Rank previous() {
        int idx = this.ordinal() - 1;
        return idx >= 0 ? values()[idx] : this;
    }
}