package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.Map;
import java.util.UUID;

public class InfoCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public InfoCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        FactionManager manager = plugin.getFactionManager();
        Faction faction = null;

        if (args.length > 0) {
            faction = manager.getByName(args[0]);
        } else if (sender instanceof Player player) {
            faction = manager.getByPlayer(player.getUniqueId());
        }

        if (faction == null) {
            Msg.send(plugin, sender, "&cPodana frakcja nie istnieje lub nie jesteś we frakcji.");
            return true;
        }

        OfflinePlayer leader = Bukkit.getOfflinePlayer(faction.getLeader());
        Msg.send(plugin, sender, "&b=== Informacje o Frakcji: &f" + faction.getName() + " &b===");
        Msg.send(plugin, sender, "&7Lider: &f" + leader.getName());
        Msg.send(plugin, sender, "&7Poziom Serca: &f" + faction.getLevel());
        Msg.send(plugin, sender, "&7Liczba członków: &f" + faction.size());

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<UUID, Rank> entry : faction.getMembers().entrySet()) {
            OfflinePlayer p = Bukkit.getOfflinePlayer(entry.getKey());
            if (!sb.isEmpty()) sb.append("&7, ");
            sb.append("&f").append(p.getName()).append(" &8(&7").append(entry.getValue().getDisplayName()).append("&8)");
        }
        Msg.send(plugin, sender, "&7Członkowie: " + sb);

        return true;
    }
}