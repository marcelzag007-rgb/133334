package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.UUID;

public class DemoteCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public DemoteCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Ta komenda jest dostępna tylko dla graczy.");
            return true;
        }

        if (args.length != 1) {
            Msg.send(plugin, player, "&cUżycie: /demote <gracz>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());
        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        Rank senderRank = faction.getRank(player.getUniqueId());
        if (senderRank.ordinal() < Rank.ZASTEPCA.ordinal()) {
            Msg.send(plugin, player, "&cTylko Lider lub Zastępca może degradować graczy.");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        UUID targetId = target.getUniqueId();

        if (!faction.isMember(targetId)) {
            Msg.send(plugin, player, "&cTen gracz nie należy do Twojej frakcji.");
            return true;
        }

        if (targetId.equals(faction.getLeader())) {
            Msg.send(plugin, player, "&cLidera nie można zdegradować.");
            return true;
        }

        Rank current = faction.getRank(targetId);
        if (current == Rank.CZLONEK) {
            Msg.send(plugin, player, "&cTen gracz ma już najniższą rangę.");
            return true;
        }

        if (current.ordinal() >= senderRank.ordinal()) {
            Msg.send(plugin, player, "&cNie możesz degradować gracza o randze równej lub wyższej od Twojej.");
            return true;
        }

        Rank newRank = current.previous();
        faction.addMember(targetId, newRank);
        manager.save();

        Msg.send(plugin, player, "&aZdegradowano gracza &f" + target.getName() + " &ado rangi: &f" + newRank.getDisplayName());

        Player onlineTarget = Bukkit.getPlayer(targetId);
        if (onlineTarget != null) {
            Msg.send(plugin, onlineTarget, "&cZostałeś zdegradowany do rangi: &f" + newRank.getDisplayName());
        }

        return true;
    }
}