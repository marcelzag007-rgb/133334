package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class ListCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public ListCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        FactionManager manager = plugin.getFactionManager();

        if (manager.getAll().isEmpty()) {
            Msg.send(plugin, sender, "&7Żadna frakcja nie została jeszcze założona.");
            return true;
        }

        Msg.send(plugin, sender, "&b--- Frakcje (" + manager.getAll().size() + ") ---");
        for (Faction f : manager.getAll()) {
            Msg.send(plugin, sender, "&f" + f.getName() + " &7- poziom " + f.getLevel()
                    + ", członków: " + f.size());
        }
        return true;
    }
}