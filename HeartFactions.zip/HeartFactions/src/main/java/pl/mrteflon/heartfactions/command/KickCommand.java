package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.UUID;

public class KickCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public KickCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /wyrzuc <gracz>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji!");
            return true;
        }

        Rank senderRank = faction.getRank(player.getUniqueId());
        if (senderRank.ordinal() < Rank.ZASTEPCA.ordinal()) {
            Msg.send(plugin, player, "&cBrak uprawnień do wyrzucania członków.");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        UUID targetUuid = target.getUniqueId();

        if (!faction.isMember(targetUuid)) {
            Msg.send(plugin, player, "&cTen gracz nie należy do Twojej frakcji.");
            return true;
        }

        if (targetUuid.equals(faction.getLeader())) {
            Msg.send(plugin, player, "&cNie można wyrzucić Lidera frakcji!");
            return true;
        }

        Rank targetRank = faction.getRank(targetUuid);
        if (targetRank.ordinal() >= senderRank.ordinal()) {
            Msg.send(plugin, player, "&cNie możesz wyrzucić gracza o równej lub wyższej randze.");
            return true;
        }

        manager.removeMember(faction, targetUuid);
        Msg.send(plugin, player, "&aWyrzucono gracza &f" + target.getName() + " &az frakcji.");

        Player onlineTarget = Bukkit.getPlayer(targetUuid);
        if (onlineTarget != null) {
            Msg.send(plugin, onlineTarget, "&cZostałeś wyrzucony z frakcji &f" + faction.getName() + "&c.");
        }

        return true;
    }
}