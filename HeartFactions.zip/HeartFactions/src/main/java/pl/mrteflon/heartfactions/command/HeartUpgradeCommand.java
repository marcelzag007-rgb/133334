package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class HeartUpgradeCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public HeartUpgradeCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null || faction.getRank(player.getUniqueId()).ordinal() < Rank.ZASTEPCA.ordinal()) {
            Msg.send(plugin, player, "&cBrak uprawnień lub nie jesteś we frakcji.");
            return true;
        }

        if (faction.getLevel() >= 5) {
            Msg.send(plugin, player, "&cFrakcja ma już maksymalny poziom (5)!");
            return true;
        }

        if (manager.wouldOverlapOnUpgrade(faction)) {
            Msg.send(plugin, player, "&cRozbudowa nachodziłaby na terytorium innej frakcji.");
            return true;
        }

        faction.setLevel(faction.getLevel() + 1);
        manager.save();

        if (faction.getHeartLocation() != null) {
            HeartStructure.generateStructure(faction.getHeartLocation(), faction.getLevel());
        }

        Msg.send(plugin, player, "&aUlepszono Serce do poziomu &f" + faction.getLevel() + "&a! Obudowa wokół Serca została wzmocniona.");
        return true;
    }
}