package pl.mrteflon.heartfactions.command;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class HeartUpgradeCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public HeartUpgradeCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    private int getUpgradeCost(int targetLevel) {
        return switch (targetLevel) {
            case 2 -> 100;
            case 3 -> 150;
            case 4 -> 200;
            case 5 -> 500;
            case 6 -> 600;
            case 7 -> 700;
            case 8 -> 800;
            case 9 -> 900;
            case 10 -> 1000;
            default -> targetLevel * 2147483647;
        };
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (faction.getRank(player.getUniqueId()) != Rank.LIDER) {
            Msg.send(plugin, player, "&cTylko Lider może ulepszać Serce.");
            return true;
        }

        if (faction.isUpgradeLocked()) {
            long remaining = faction.getUpgradeLockRemainingSeconds();
            long minutes = remaining / 60;
            long seconds = remaining % 60;
            Msg.send(plugin, player, "&cSerce dopiero co straciło poziom - ulepszanie zablokowane jeszcze przez &e"
                    + minutes + " min " + seconds + " s&c.");
            return true;
        }

        int nextLevel = faction.getLevel() + 1;
        int cost = getUpgradeCost(nextLevel);

        if (!player.getInventory().containsAtLeast(new ItemStack(Material.EMERALD), cost)) {
            Msg.send(plugin, player, "&cDo ulepszenia na poziom &e" + nextLevel + " &cpotrzebujesz &a" + cost + " Emeraldów&c!");
            return true;
        }

        if (manager.wouldOverlapOnUpgrade(faction)) {
            Msg.send(plugin, player, "&cNie możesz ulepszyć Serca – teren po ulepszeniu nachodziłby na inną frakcję!");
            return true;
        }

        player.getInventory().removeItem(new ItemStack(Material.EMERALD, cost));

        faction.setLevel(nextLevel);
        manager.save();

        HeartStructure.generateStructure(faction.getHeartLocation(), nextLevel);

        Msg.send(plugin, player, "&aUlepszono Serce do poziomu &e" + nextLevel + "&a! Pobrano &a" + cost + " Emeraldów&a.");
        return true;
    }
}