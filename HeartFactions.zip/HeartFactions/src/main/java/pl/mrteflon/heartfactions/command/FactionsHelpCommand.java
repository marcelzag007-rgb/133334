package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.util.Msg;

public class FactionsHelpCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public FactionsHelpCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Msg.send(plugin, sender, "&b=== Komendy Frakcji ===");
        Msg.send(plugin, sender, "&e/stworz <nazwa> &7- zakłada frakcję, Serce powstaje tam, gdzie stoisz");
        Msg.send(plugin, sender, "&e/heartupgrade &7- ulepsza Serce i wzmacnia obudowę &8(Zastępca+)");
        Msg.send(plugin, sender, "&e/granica &7- pokazuje/ukrywa granice terytorium (cząsteczki)");
        Msg.send(plugin, sender, "&e/zapros <gracz> &7- zaprasza gracza do frakcji &8(Zastępca+)");
        Msg.send(plugin, sender, "&e/dolacz <nazwa> &7- akceptuje zaproszenie do frakcji");
        Msg.send(plugin, sender, "&e/odrzuc <nazwa> &7- odrzuca zaproszenie do frakcji");
        Msg.send(plugin, sender, "&e/wyrzuc <gracz> &7- wyrzuca gracza z frakcji &8(Zastępca+)");
        Msg.send(plugin, sender, "&e/promo <gracz> &7- awansuje gracza &8(Zastępca+)");
        Msg.send(plugin, sender, "&e/demote <gracz> &7- degraduje gracza &8(Zastępca+)");
        Msg.send(plugin, sender, "&e/opusc &7- opuszcza obecną frakcję");
        Msg.send(plugin, sender, "&e/rozwiaz &7- rozwiązuje frakcję &8(Lider)");
        Msg.send(plugin, sender, "&e/finfo [nazwa] &7- informacje o frakcji");
        Msg.send(plugin, sender, "&e/flist &7- lista wszystkich frakcji");
        Msg.send(plugin, sender, "&e/ustawdomfrakcji &7- ustawia dom frakcji w tym miejscu &8(Lider)");
        Msg.send(plugin, sender, "&e/domfrakcji &7- teleportuje do domu frakcji");
        return true;
    }
}
