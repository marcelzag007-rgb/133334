package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.UUID;

public class PromoCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public PromoCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Ta komenda jest dostępna tylko dla graczy.");
            return true;
        }

        if (args.length != 1) {
            Msg.send(plugin, player, "&cUżycie: /promo <gracz>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());
        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        Rank senderRank = faction.getRank(player.getUniqueId());
        if (senderRank.ordinal() < Rank.ZASTEPCA.ordinal()) {
            Msg.send(plugin, player, "&cTylko Lider lub Zastępca może awansować graczy.");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        UUID targetId = target.getUniqueId();

        if (!faction.isMember(targetId)) {
            Msg.send(plugin, player, "&cTen gracz nie należy do Twojej frakcji.");
            return true;
        }

        Rank current = faction.getRank(targetId);
        if (current == Rank.LIDER) {
            Msg.send(plugin, player, "&cLider już zajmuje najwyższą rangę.");
            return true;
        }

        if (current.ordinal() >= Rank.highestPromotable().ordinal()) {
            Msg.send(plugin, player, "&cTen gracz osiągnął maksymalną rangę możliwą do nadania (Zastępca).");
            return true;
        }

        if (current.next().ordinal() >= senderRank.ordinal()) {
            Msg.send(plugin, player, "&cNie możesz awansować gracza na rangę równą lub wyższą od Twojej.");
            return true;
        }

        Rank newRank = current.next();
        faction.addMember(targetId, newRank);
        manager.save();

        Msg.send(plugin, player, "&aGracz &f" + target.getName() + " &aawansowany na: &f" + newRank.getDisplayName());

        Player onlineTarget = Bukkit.getPlayer(targetId);
        if (onlineTarget != null) {
            Msg.send(plugin, onlineTarget, "&aZostałeś awansowany na rangę: &f" + newRank.getDisplayName());
        }

        return true;
    }
}