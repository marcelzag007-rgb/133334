package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class AcceptCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public AcceptCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /dolacz <nazwa_frakcji>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        if (manager.getByPlayer(player.getUniqueId()) != null) {
            Msg.send(plugin, player, "&cNależysz już do jakiejś frakcji!");
            return true;
        }

        Faction faction = manager.getByName(args[0]);
        if (faction == null) {
            Msg.send(plugin, player, "&cFrakcja o takiej nazwie nie istnieje.");
            return true;
        }

        if (!manager.hasInvite(player.getUniqueId(), faction)) {
            Msg.send(plugin, player, "&cNie masz zaproszenia do tej frakcji.");
            return true;
        }

        manager.clearInvite(player.getUniqueId(), faction);
        manager.addMember(faction, player.getUniqueId());
        Msg.send(plugin, player, "&aDołączyłeś do frakcji &f" + faction.getName() + "&a!");
        return true;
    }
}