package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class DisbandCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public DisbandCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Komenda tylko dla graczy.");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (faction.getRank(player.getUniqueId()) != Rank.LIDER) {
            Msg.send(plugin, player, "&cTylko Lider frakcji może ją rozwiązać.");
            return true;
        }

        Location heartLoc = faction.getHeartLocation();

        // Usuwanie fizycznej kuli i czyszczenie terenu
        if (heartLoc != null) {
            HeartStructure.removeStructure(heartLoc);
        }

        String factionName = faction.getName();

        // Usuwanie frakcji z pamięci i konfiguracji
        manager.disbandFaction(faction);

        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cFrakcja §l" + factionName + " §czostała rozwiązana przez Lidera §l" + player.getName() + "§c!");

        return true;
    }
}