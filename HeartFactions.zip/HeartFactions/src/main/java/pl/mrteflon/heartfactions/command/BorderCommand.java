package pl.mrteflon.heartfactions.command;

import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BorderCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;
    private final Map<UUID, BukkitTask> activeTasks = new HashMap<>();

    public BorderCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Tylko gracz może użyć tej komendy.");
            return true;
        }

        UUID uuid = player.getUniqueId();

        // Jeśli granice są już włączone -> wyłączamy je
        if (activeTasks.containsKey(uuid)) {
            activeTasks.remove(uuid).cancel();
            Msg.send(plugin, player, "&cWyłączono widok granic.");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(uuid);

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji!");
            return true;
        }

        // Włączamy cykliczne odświeżanie particlesów co 1 sekundę (20 ticków)
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    activeTasks.remove(uuid);
                    return;
                }

                Faction currentFaction = plugin.getFactionManager().getByPlayer(uuid);
                if (currentFaction == null) {
                    cancel();
                    activeTasks.remove(uuid);
                    Msg.send(plugin, player, "&cNie należysz już do frakcji. Widok granic został wyłączony.");
                    return;
                }

                int radius = manager.radiusForLevel(currentFaction.getLevel());
                int centerChunkX = currentFaction.getHeartChunkX();
                int centerChunkZ = currentFaction.getHeartChunkZ();

                int minChunkX = centerChunkX - radius;
                int maxChunkX = centerChunkX + radius;
                int minChunkZ = centerChunkZ - radius;
                int maxChunkZ = centerChunkZ + radius;

                int minX = minChunkX << 4;
                int maxX = (maxChunkX << 4) + 15;
                int minZ = minChunkZ << 4;
                int maxZ = (maxChunkZ << 4) + 15;

                double playerY = player.getLocation().getY();

                // Zwiększamy zakres w górę i w dół, aby łatwiej zauważyć ramę
                for (double y = playerY - 2; y <= playerY + 4; y += 0.5) {
                    for (int x = minX; x <= maxX; x += 1) { // Gęstszy krok (co 1 blok zamiast 3)
                        player.spawnParticle(Particle.FLAME, x, y, minZ, 1, 0, 0, 0, 0);
                        player.spawnParticle(Particle.FLAME, x, y, maxZ, 1, 0, 0, 0, 0);
                    }
                    for (int z = minZ; z <= maxZ; z += 1) {
                        player.spawnParticle(Particle.FLAME, minX, y, z, 1, 0, 0, 0, 0);
                        player.spawnParticle(Particle.FLAME, maxX, y, z, 1, 0, 0, 0, 0);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);

        activeTasks.put(uuid, task);
        Msg.send(plugin, player, "&aWłączono widok granic! Wpisz ponowne &e/granica&a, aby go wyłączyć.");
        return true;
    }
}