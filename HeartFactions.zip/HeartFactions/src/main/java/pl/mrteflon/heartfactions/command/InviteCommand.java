package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class InviteCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public InviteCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /zapros <gracz>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji!");
            return true;
        }

        if (faction.getRank(player.getUniqueId()).ordinal() < Rank.ZASTEPCA.ordinal()) {
            Msg.send(plugin, player, "&cMusisz mieć rangę Zastępca lub Lider, aby zapraszać.");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            Msg.send(plugin, player, "&cGracz jest offline.");
            return true;
        }

        if (manager.getByPlayer(target.getUniqueId()) != null) {
            Msg.send(plugin, player, "&cTen gracz należy już do jakiejś frakcji.");
            return true;
        }

        manager.invite(faction, target.getUniqueId());
        Msg.send(plugin, player, "&aZaproszono gracza &f" + target.getName() + " &ado frakcji!");
        Msg.send(plugin, target, "&aZostałeś zaproszony do frakcji &f" + faction.getName() + "&a! Wpisz &e/dolacz " + faction.getName() + " &ahab &e/odrzuc " + faction.getName() + "&a.");

        return true;
    }
}