package pl.mrteflon.heartfactions.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.*;

public class Faction {

    private final String name;
    private UUID leader;
    private final Map<UUID, Rank> members = new LinkedHashMap<>();
    private final Set<String> allies = new HashSet<>();

    private String world;
    private int heartX, heartY, heartZ;
    private int level = 1;
    private int currentHeartLives = 1;

    // Czas (w milisekundach), po którym wygasa blokada ulepszania Serca
    private long upgradeCooldownUntil = 0;

    private String homeWorld;
    private double homeX, homeY, homeZ;
    private float homeYaw, homePitch;

    public Faction(String name, UUID leader, Location heart) {
        this.name = name;
        this.leader = leader;
        this.members.put(leader, Rank.LIDER);
        setHeart(heart);
        setHome(heart);
    }

    public void setHeart(Location loc) {
        if (loc.getWorld() != null) {
            this.world = loc.getWorld().getName();
        }
        this.heartX = loc.getBlockX();
        this.heartY = loc.getBlockY();
        this.heartZ = loc.getBlockZ();
    }

    public Location getHeartLocation() {
        World w = Bukkit.getWorld(world);
        if (w == null) return null;
        return new Location(w, heartX + 0.5, heartY, heartZ + 0.5);
    }

    public void setHome(Location loc) {
        if (loc.getWorld() != null) {
            this.homeWorld = loc.getWorld().getName();
        }
        this.homeX = loc.getX();
        this.homeY = loc.getY();
        this.homeZ = loc.getZ();
        this.homeYaw = loc.getYaw();
        this.homePitch = loc.getPitch();
    }

    public boolean hasHome() {
        return homeWorld != null && Bukkit.getWorld(homeWorld) != null;
    }

    public Location getHomeLocation() {
        if (!hasHome()) return getHeartLocation();
        World w = Bukkit.getWorld(homeWorld);
        if (w == null) return null;
        return new Location(w, homeX, homeY, homeZ, homeYaw, homePitch);
    }

    public String getWorldName() { return world; }
    public int getHeartChunkX() { return heartX >> 4; }
    public int getHeartChunkZ() { return heartZ >> 4; }
    public int getLevel() { return level; }

    public void setLevel(int level) {
        this.level = level;
        this.currentHeartLives = level;
    }

    // Metoda wywoływana, gdy poziom Serca spada po jego zniszczeniu
    public void downgradeLevel() {
        if (this.level > 1) {
            this.level--;
        }
        this.currentHeartLives = this.level;

        // Ustawienie blokady ulepszania na 30 minut (30 * 60 * 1000 ms) od teraz
        this.upgradeCooldownUntil = System.currentTimeMillis() + (30 * 60 * 1000L);
    }

    public int getCurrentHeartLives() { return currentHeartLives; }
    public void setCurrentHeartLives(int currentHeartLives) { this.currentHeartLives = currentHeartLives; }
    public String getName() { return name; }
    public UUID getLeader() { return leader; }
    public void setLeader(UUID leader) { this.leader = leader; }
    public Map<UUID, Rank> getMembers() { return members; }
    public boolean isMember(UUID uuid) { return members.containsKey(uuid); }
    public Rank getRank(UUID uuid) { return members.get(uuid); }
    public void addMember(UUID uuid, Rank rank) { members.put(uuid, rank); }

    public int size() {
        return members.size();
    }

    // Sprawdza, czy trwa 30-minutowy cooldown ulepszania
    public boolean isUpgradeLocked() {
        return System.currentTimeMillis() < upgradeCooldownUntil;
    }

    // Zwraca czas w sekundach pozostały do końca blokady ulepszania
    public long getUpgradeLockRemainingSeconds() {
        long remainingMs = upgradeCooldownUntil - System.currentTimeMillis();
        return Math.max(0, remainingMs / 1000);
    }

    // --- SOJUSZE ---
    public Set<String> getAllies() { return allies; }
    public boolean isAlly(String factionName) { return allies.contains(factionName.toLowerCase()); }
    public void addAlly(String factionName) { allies.add(factionName.toLowerCase()); }
    public void removeAlly(String factionName) { allies.remove(factionName.toLowerCase()); }

    public String getHomeWorld() { return homeWorld; }
    public double getHomeX() { return homeX; }
    public double getHomeY() { return homeY; }
    public double getHomeZ() { return homeZ; }
    public float getHomeYaw() { return homeYaw; }
    public float getHomePitch() { return homePitch; }
    public void setHomeRaw(String w, double x, double y, double z, float yaw, float pitch) {
        this.homeWorld = w;
        this.homeX = x;
        this.homeY = y;
        this.homeZ = z;
        this.homeYaw = yaw;
        this.homePitch = pitch;
    }
}