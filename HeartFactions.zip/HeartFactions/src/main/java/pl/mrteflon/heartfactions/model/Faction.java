package pl.mrteflon.heartfactions.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class Faction {

    private final String name;
    private UUID leader;
    private final Map<UUID, Rank> members = new LinkedHashMap<>();

    private String world;
    private int heartX, heartY, heartZ;
    private int level = 1;

    private String homeWorld;
    private double homeX, homeY, homeZ;
    private float homeYaw, homePitch;
    private boolean homeSet = false;

    public Faction(String name, UUID leader, Location heart) {
        this.name = name;
        this.leader = leader;
        this.members.put(leader, Rank.LIDER);
        setHeart(heart);
    }

    public void setHeart(Location loc) {
        if (loc.getWorld() != null) {
            this.world = loc.getWorld().getName();
        }
        this.heartX = loc.getBlockX();
        this.heartY = loc.getBlockY();
        this.heartZ = loc.getBlockZ();
    }

    public Location getHeartLocation() {
        World w = Bukkit.getWorld(world);
        if (w == null) return null;
        return new Location(w, heartX + 0.5, heartY, heartZ + 0.5);
    }

    public String getWorldName() {
        return world;
    }

    public int getHeartChunkX() {
        return heartX >> 4;
    }

    public int getHeartChunkZ() {
        return heartZ >> 4;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    // --- Dom frakcji ---

    public void setHome(Location loc) {
        if (loc.getWorld() == null) return;
        this.homeWorld = loc.getWorld().getName();
        this.homeX = loc.getX();
        this.homeY = loc.getY();
        this.homeZ = loc.getZ();
        this.homeYaw = loc.getYaw();
        this.homePitch = loc.getPitch();
        this.homeSet = true;
    }

    public boolean hasHome() {
        return homeSet;
    }

    public Location getHomeLocation() {
        if (!homeSet) return null;
        World w = Bukkit.getWorld(homeWorld);
        if (w == null) return null;
        return new Location(w, homeX, homeY, homeZ, homeYaw, homePitch);
    }

    public String getName() {
        return name;
    }

    public UUID getLeader() {
        return leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public Map<UUID, Rank> getMembers() {
        return members;
    }

    public boolean isMember(UUID uuid) {
        return members.containsKey(uuid);
    }

    public Rank getRank(UUID uuid) {
        return members.get(uuid);
    }

    public void addMember(UUID uuid, Rank rank) {
        members.put(uuid, rank);
    }

    public int size() {
        return members.size();
    }
}