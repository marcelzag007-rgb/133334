package pl.mrteflon.heartfactions.listener;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.HeartStructure;
import pl.mrteflon.heartfactions.util.Msg;

public class ProtectionListener implements Listener {

    private final HeartFactionsPlugin plugin;

    public ProtectionListener(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    // --- OCHRONA NISZCZENIA BLOKÓW ORAZ USUWANIE DROPÓW DLA OBUDOWY SERCA ---
    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        FactionManager manager = plugin.getFactionManager();
        Block block = event.getBlock();
        Faction faction = manager.getFactionAt(block.getChunk());

        if (faction != null) {
            // Jeśli to nie jest członek frakcji - całkowita blokada niszczenia
            if (!faction.isMember(player.getUniqueId())) {
                Msg.send(plugin, player, "&cNie możesz niszczyć bloków na terenie obcej frakcji!");
                event.setCancelled(true);
                return;
            }

            // Jeśli to członek frakcji, sprawdzamy czy blok należy do obudowy Serca
            Location heartLoc = faction.getHeartLocation();
            if (heartLoc != null && heartLoc.distance(block.getLocation()) <= 3.5) {
                if (block.getType() == Material.OBSIDIAN || block.getType() == Material.CRYING_OBSIDIAN) {
                    // Anulujemy wykopanie i czyścimy blok ręcznie bez dropu
                    event.setCancelled(true);
                    block.setType(Material.AIR, false);
                }
            }
        }
    }

    // --- STAWIANIE BLOKÓW / STAWIANIE C4 NA TERENIE WROGA ---
    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItemInHand();

        // 1. Sprawdzenie, czy stawiany blok to C4
        if (item != null && item.getType() == Material.TNT && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            if ("§c§lC4".equals(item.getItemMeta().getDisplayName())) {
                event.setCancelled(true); // Anulujemy postawienie zwykłego bloku

                // Zabieramy 1 sztukę z dłoni gracza
                if (item.getAmount() > 1) {
                    item.setAmount(item.getAmount() - 1);
                } else {
                    player.getInventory().setItemInMainHand(null);
                }

                // Stawiamy podpalony dynamit C4
                TNTPrimed tnt = (TNTPrimed) event.getBlock().getWorld().spawnEntity(
                        event.getBlock().getLocation().add(0.5, 0, 0.5), EntityType.TNT);
                tnt.setFuseTicks(80); // 4 sekundy lontu
                tnt.setCustomName("§c§lC4");
                tnt.setCustomNameVisible(true);
                return;
            }
        }

        // 2. Zwykła ochrona budowania dla reszty bloków
        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getBlock().getChunk());

        if (faction != null && !faction.isMember(player.getUniqueId())) {
            Msg.send(plugin, player, "&cNie możesz stawiać bloków na terenie obcej frakcji!");
            event.setCancelled(true);
        }
    }

    // --- BLOKADA PVP I ATAKOWANIA SOJUSZNIKÓW ---
    @EventHandler(ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player victim && event.getDamager() instanceof Player attacker) {
            FactionManager manager = plugin.getFactionManager();
            Faction f1 = manager.getByPlayer(attacker.getUniqueId());
            Faction f2 = manager.getByPlayer(victim.getUniqueId());

            if (f1 != null && f2 != null) {
                if (f1.equals(f2)) {
                    Msg.send(plugin, attacker, "&cNie możesz atakować członków swojej frakcji!");
                    event.setCancelled(true);
                } else if (f1.isAlly(f2.getName())) {
                    Msg.send(plugin, attacker, "&cNie możesz atakować swoich SOJUSZNIKÓW!");
                    event.setCancelled(true);
                }
            }
        }
    }

    // --- NISZCZENIE SERCA (OBRAŻENIA W ENDER CRYSTAL) ---
    @EventHandler(ignoreCancelled = true)
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (event.getEntityType() != EntityType.END_CRYSTAL) return;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getEntity().getLocation().getChunk());

        if (faction != null) {
            Location heartLoc = faction.getHeartLocation();

            if (heartLoc != null && heartLoc.distance(event.getEntity().getLocation()) < 3.0) {
                if (event.getDamager() instanceof Player player) {
                    Faction attackerFaction = manager.getByPlayer(player.getUniqueId());

                    if (faction.isMember(player.getUniqueId())) {
                        Msg.send(plugin, player, "&cNie możesz zniszczyć własnego Serca!");
                        event.setCancelled(true);
                        return;
                    }

                    if (attackerFaction != null && attackerFaction.isAlly(faction.getName())) {
                        Msg.send(plugin, player, "&cNie możesz atakować Serca swojego SOJUSZNIKA!");
                        event.setCancelled(true);
                        return;
                    }

                    event.setCancelled(true);

                    int currentLives = faction.getCurrentHeartLives();
                    if (currentLives > 1) {
                        faction.setCurrentHeartLives(currentLives - 1);
                        manager.save();
                        Msg.send(plugin, player, "&eAtakujesz Serce! Pozostałe życia Serca: &c" + (currentLives - 1) + "/" + faction.getLevel());
                        return;
                    }

                    int currentLevel = faction.getLevel();

                    if (currentLevel > 1) {
                        faction.downgradeLevel();
                        manager.save();

                        HeartStructure.removeStructure(heartLoc);
                        event.getEntity().remove();

                        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cSerce frakcji §l" + faction.getName() +
                                " §czostało zniszczone przez §l" + player.getName() + "§c! Poziom frakcji spadł do §e" + faction.getLevel() +
                                "§c. Ulepszenie zablokowane na 30 minut. Serce odrodzi się za §l10 minut§c!");

                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                Faction checkF = manager.getByName(faction.getName());
                                if (checkF != null && checkF.getHeartLocation() != null) {
                                    HeartStructure.generateStructure(checkF.getHeartLocation(), checkF.getLevel());
                                    Bukkit.broadcastMessage("§8[§bFrakcje§8] §aSerce frakcji §l" + checkF.getName() + " §anowu odrodziło się z nową obudową!");
                                }
                            }
                        }.runTaskLater(plugin, 12000L); // 10 minut = 12000 ticków

                    } else {
                        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cFrakcja §l" + faction.getName() + " §czostała całkowicie zniszczona przez §l" + player.getName() + "§c!");

                        HeartStructure.removeStructure(heartLoc);
                        event.getEntity().remove();
                        manager.disbandFaction(faction);
                    }
                } else {
                    event.setCancelled(true);
                }
            }
        }
    }

    // --- EKSPLOZJA C4 ORAZ OCHRONA PRZED ZWYKŁYM TNT ---
    @EventHandler(ignoreCancelled = true)
    public void onC4Explode(EntityExplodeEvent event) {
        if (event.getEntityType() == EntityType.TNT && "§c§lC4".equals(event.getEntity().getCustomName())) {
            event.blockList().clear();

            Location loc = event.getLocation();
            int radius = 4;

            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        Block b = loc.clone().add(x, y, z).getBlock();
                        if (b.getType() != Material.AIR && b.getType() != Material.BEDROCK) {
                            if (loc.distance(b.getLocation()) <= radius) {
                                b.setType(Material.AIR, false);
                            }
                        }
                    }
                }
            }
            return;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getLocation().getChunk());
        if (faction != null) {
            event.blockList().clear();
        }
    }
}