package pl.mrteflon.heartfactions.listener;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class ProtectionListener implements Listener {

    private final HeartFactionsPlugin plugin;
    private final Map<UUID, BossBar> playerBossBars = new HashMap<>();

    public ProtectionListener(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean canBuild(Player player, Block block) {
        if (!plugin.getConfig().getBoolean("protection.protect-blocks", true)) return true;

        FactionManager manager = plugin.getFactionManager();
        Faction owner = manager.getFactionAt(block.getChunk());
        if (owner == null) return true;

        return owner.isMember(player.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!canBuild(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie możesz tu niszczyć bloków.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!canBuild(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie możesz tu stawiać bloków.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!plugin.getConfig().getBoolean("protection.protect-containers", true)) return;

        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!(block.getState() instanceof InventoryHolder)) return;

        if (!canBuild(event.getPlayer(), block)) {
            event.setCancelled(true);
            Msg.send(plugin, event.getPlayer(), "&cTo teren obcej frakcji. Nie masz dostępu do tego kontenera.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        if (!plugin.getConfig().getBoolean("protection.protect-explosions", true)) return;

        FactionManager manager = plugin.getFactionManager();
        Iterator<Block> it = event.blockList().iterator();
        while (it.hasNext()) {
            Block block = it.next();
            if (manager.getFactionAt(block.getChunk()) != null) {
                it.remove();
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCrystalDamage(EntityDamageByEntityEvent event) {
        if (event.getEntityType() != EntityType.END_CRYSTAL) return;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getEntity().getLocation().getChunk());

        if (faction == null) return;

        Location heartLoc = faction.getHeartLocation();
        if (heartLoc == null || heartLoc.distance(event.getEntity().getLocation()) >= 2.0) return;

        if (!(event.getDamager() instanceof Player player)) {
            event.setCancelled(true);
            return;
        }

        if (faction.isMember(player.getUniqueId())) {
            Msg.send(plugin, player, "&cNie możesz zniszczyć własnego Serca!");
            event.setCancelled(true);
            return;
        }

        String factionName = faction.getName();
        String attackerName = player.getName();

        // Ostatnie życie (poziom 1) - Serce ginie ostatecznie, frakcja przestaje istnieć.
        if (faction.getLevel() <= 1) {
            Bukkit.broadcastMessage("§8[§bFrakcje§8] §cFrakcja \"§l" + factionName
                    + "§c\" została zniszczona przez \"§l" + attackerName + "§c\"!");
            manager.disbandFaction(faction);
            return;
        }

        // Serce traci jedno "życie" - poziom (a razem z nim promień terytorium) spada od razu.
        faction.setLevel(faction.getLevel() - 1);
        manager.save();

        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cSerce frakcji §l" + factionName
                + " §czostało trafione przez §l" + attackerName
                + "§c! Poziom spadł do §l" + faction.getLevel() + "§c. Odrodzi się za 60 sekund.");

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Faction current = manager.getByName(factionName);
            if (current == null) return; // frakcja mogła zostać rozwiązana zanim Serce zdążyło się odrodzić

            Location loc = current.getHeartLocation();
            if (loc == null || loc.getWorld() == null) return;

            HeartStructure.generateStructure(loc, current.getLevel());
            Bukkit.broadcastMessage("§8[§bFrakcje§8] §aSerce frakcji §l" + current.getName()
                    + " §aodrodziło się na poziomie §l" + current.getLevel() + "§a!");
        }, 20L * 60);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getFactionAt(event.getTo().getChunk());

        if (faction != null) {
            BossBar bar = playerBossBars.computeIfAbsent(player.getUniqueId(), k -> {
                BossBar newBar = Bukkit.createBossBar("", BarColor.RED, BarStyle.SOLID);
                newBar.addPlayer(player);
                return newBar;
            });
            bar.setTitle("§cTeren Frakcji: §l" + faction.getName() + " §7(Poziom " + faction.getLevel() + ")");
            bar.setVisible(true);
        } else {
            BossBar bar = playerBossBars.get(player.getUniqueId());
            if (bar != null) {
                bar.setVisible(false);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        BossBar bar = playerBossBars.remove(event.getPlayer().getUniqueId());
        if (bar != null) {
            bar.removeAll();
        }
    }
}