package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.util.Msg;

public class HelpCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public HelpCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Msg.send(plugin, sender, "&b=== KOMENDY FRAKCJI ===");
        Msg.send(plugin, sender, "&e/stworz <nazwa> &7- Tworzy nową frakcję");
        Msg.send(plugin, sender, "&e/rozwiaz &7- Rozwiązuje frakcję (Lider)");
        Msg.send(plugin, sender, "&e/finfo [nazwa] &7- Pokazuje informacje o frakcji");
        Msg.send(plugin, sender, "&e/flist &7- Lista wszystkich frakcji");
        Msg.send(plugin, sender, "&e/heartupgrade &7- Ulepsza Serce i obudowę");
        Msg.send(plugin, sender, "&e/granica &7- Włącza/wyłącza widok granic");
        Msg.send(plugin, sender, "&e/ustawdomfrakcji &7- Ustawia dom frakcji");
        Msg.send(plugin, sender, "&e/domfrakcji &7- Teleportuje do domu frakcji");
        Msg.send(plugin, sender, "&e/zapros <gracz> &7- Zaprasza gracza");
        Msg.send(plugin, sender, "&e/dolacz <nazwa> &7- Dołącza do frakcji");
        Msg.send(plugin, sender, "&e/odrzuc <nazwa> &7- Odrzuca zaproszenie");
        Msg.send(plugin, sender, "&e/wyrzuc <gracz> &7- Wyrzuca członka");
        Msg.send(plugin, sender, "&e/opusc &7- Opuszcza frakcję");
        Msg.send(plugin, sender, "&e/promo <gracz> &7- Awansuje członka");
        Msg.send(plugin, sender, "&e/demote <gracz> &7- Degraduje członka");
        return true;
    }
}