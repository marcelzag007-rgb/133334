package pl.mrteflon.heartfactions.command;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class HomeCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public HomeCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Ta komenda jest dostępna tylko dla graczy.");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());
        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (!faction.hasHome()) {
            Msg.send(plugin, player, "&cLider nie ustawił jeszcze domu frakcji. Użyj &e/ustawdomfrakcji&c.");
            return true;
        }

        Location home = faction.getHomeLocation();
        if (home == null || home.getWorld() == null) {
            Msg.send(plugin, player, "&cŚwiat, w którym znajduje się dom frakcji, jest obecnie niedostępny.");
            return true;
        }

        player.teleport(home);
        Msg.send(plugin, player, "&aTeleportowano do domu frakcji.");
        return true;
    }
}
