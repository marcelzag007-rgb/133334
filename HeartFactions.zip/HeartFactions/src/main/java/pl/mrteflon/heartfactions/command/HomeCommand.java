package pl.mrteflon.heartfactions.command;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class HomeCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public HomeCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());

        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        Location home = faction.getHomeLocation();
        if (home == null || home.getWorld() == null) {
            Msg.send(plugin, player, "&cDom frakcji nie został jeszcze ustawiony.");
            return true;
        }

        Location startLoc = player.getLocation().clone();
        Msg.send(plugin, player, "&eTeleportacja nastąpi za &a5 sekund&e. Nie ruszaj się!");

        new BukkitRunnable() {
            int secondsLeft = 5;

            @Override
            public void run() {
                // Sprawdzanie czy gracz jest online
                if (!player.isOnline()) {
                    cancel();
                    return;
                }

                // Sprawdzanie czy gracz zmienił pozycję (poruszył się)
                Location currentLoc = player.getLocation();
                if (startLoc.getBlockX() != currentLoc.getBlockX() ||
                        startLoc.getBlockY() != currentLoc.getBlockY() ||
                        startLoc.getBlockZ() != currentLoc.getBlockZ()) {

                    Msg.send(plugin, player, "&cRuszyłeś się! Teleportacja została anulowana.");
                    cancel();
                    return;
                }

                secondsLeft--;

                if (secondsLeft > 0) {
                    Msg.send(plugin, player, "&eTeleportacja za &a" + secondsLeft + " sek&e...");
                } else {
                    player.teleport(home);
                    Msg.send(plugin, player, "&aPrzeteleportowano do domu frakcji!");
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 20L, 20L); // Uruchamia się co 20 ticków (1 sekunda)

        return true;
    }
}