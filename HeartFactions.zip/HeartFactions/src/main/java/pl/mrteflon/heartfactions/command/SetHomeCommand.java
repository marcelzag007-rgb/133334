package pl.mrteflon.heartfactions.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class SetHomeCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public SetHomeCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Ta komenda jest dostępna tylko dla graczy.");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction faction = manager.getByPlayer(player.getUniqueId());
        if (faction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (!player.getUniqueId().equals(faction.getLeader())) {
            Msg.send(plugin, player, "&cTylko Lider może ustawić dom frakcji.");
            return true;
        }

        faction.setHome(player.getLocation());
        manager.save();

        Msg.send(plugin, player, "&aDom frakcji ustawiony w miejscu, w którym stoisz.");
        return true;
    }
}
