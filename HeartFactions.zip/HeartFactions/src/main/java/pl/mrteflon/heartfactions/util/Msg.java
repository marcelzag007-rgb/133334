package pl.mrteflon.heartfactions.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;

public final class Msg {

    private Msg() {}

    public static void send(HeartFactionsPlugin plugin, CommandSender target, String message) {
        String prefix = plugin.getConfig().getString("messages.prefix", "&8[&bFrakcje&8] &r");
        target.sendMessage(ChatColor.translateAlternateColorCodes('&', prefix + message));
    }
}