package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class AllyCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public AllyCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /sojusz <nazwa_frakcji>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction myFaction = manager.getByPlayer(player.getUniqueId());

        if (myFaction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (myFaction.getRank(player.getUniqueId()) != Rank.LIDER) {
            Msg.send(plugin, player, "&cTylko Lider może nawiązywać sojusze.");
            return true;
        }

        Faction targetFaction = manager.getByName(args[0]);
        if (targetFaction == null) {
            Msg.send(plugin, player, "&cNie znaleziono frakcji &e" + args[0]);
            return true;
        }

        if (myFaction.equals(targetFaction)) {
            Msg.send(plugin, player, "&cNie możesz zawrzeć sojuszu z własną frakcją.");
            return true;
        }

        if (myFaction.isAlly(targetFaction.getName())) {
            Msg.send(plugin, player, "&cJesteście już w sojuszu z frakcją &e" + targetFaction.getName() + "&c!");
            return true;
        }

        // Jeśli druga frakcja wysłała już zaproszenie -> Akceptujemy i tworzymy sojusz
        if (manager.hasAllyInvite(targetFaction, myFaction)) {
            manager.createAlliance(myFaction, targetFaction);
            Bukkit.broadcastMessage("§8[§bFrakcje§8] §aFrakcja §l" + myFaction.getName() + " §ai §l" + targetFaction.getName() + " §azawarły SOJUSZ!");
            return true;
        }

        // W przeciwnym razie wysyłamy zaproszenie
        manager.inviteAlly(myFaction, targetFaction);
        Msg.send(plugin, player, "&aWysyłano prośbę o sojusz do frakcji &e" + targetFaction.getName() + "&a.");

        Player targetLeader = Bukkit.getPlayer(targetFaction.getLeader());
        if (targetLeader != null && targetLeader.isOnline()) {
            Msg.send(plugin, targetLeader, "&eFrakcja &a" + myFaction.getName() + " &ewysłała prośbę o SOJUSZ! Wpisz &a/sojusz " + myFaction.getName() + " &eaby zaakceptować.");
        }

        return true;
    }
}