package pl.mrteflon.heartfactions.manager;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class FactionManager {

    private final HeartFactionsPlugin plugin;
    private final Map<String, Faction> factionsByName = new HashMap<>();
    private final Map<UUID, String> factionOfPlayer = new HashMap<>();
    private final Map<UUID, Set<String>> playerInvites = new HashMap<>();
    private final Map<String, Set<String>> allyInvites = new HashMap<>();
    private File dataFile;

    public FactionManager(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    public int radiusForLevel(int level) {
        return Math.min(level, 10);
    }

    public boolean existsByName(String name) {
        return name != null && factionsByName.containsKey(name.toLowerCase());
    }

    public Faction getByName(String name) {
        if (name == null) return null;
        return factionsByName.get(name.toLowerCase());
    }

    public Faction getByPlayer(UUID uuid) {
        String name = factionOfPlayer.get(uuid);
        return name != null ? factionsByName.get(name) : null;
    }

    public Faction getFactionAt(Chunk chunk) {
        for (Faction f : factionsByName.values()) {
            if (!f.getWorldName().equals(chunk.getWorld().getName())) continue;

            int radius = radiusForLevel(f.getLevel());
            int cx = f.getHeartChunkX();
            int cz = f.getHeartChunkZ();

            if (Math.abs(chunk.getX() - cx) <= radius && Math.abs(chunk.getZ() - cz) <= radius) {
                return f;
            }
        }
        return null;
    }

    public Faction createFaction(String name, UUID leader, Location heart) {
        Faction f = new Faction(name, leader, heart);
        factionsByName.put(name.toLowerCase(), f);
        factionOfPlayer.put(leader, name.toLowerCase());
        save();
        return f;
    }

    public void disbandFaction(Faction faction) {
        if (faction == null) return;
        String lowerName = faction.getName().toLowerCase();

        for (UUID memberUuid : faction.getMembers().keySet()) {
            factionOfPlayer.remove(memberUuid);
        }

        for (String allyName : new ArrayList<>(faction.getAllies())) {
            Faction ally = getByName(allyName);
            if (ally != null) {
                ally.removeAlly(lowerName);
            }
        }

        Location loc = faction.getHeartLocation();
        if (loc != null && loc.getWorld() != null) {
            for (Entity e : loc.getWorld().getNearbyEntities(loc, 5, 5, 5)) {
                if (e.getType() == EntityType.END_CRYSTAL) {
                    e.remove();
                }
            }
        }

        factionsByName.remove(lowerName);
        save();
    }

    public void invite(Faction faction, UUID playerUuid) {
        if (faction == null) return;
        playerInvites.computeIfAbsent(playerUuid, k -> new HashSet<>()).add(faction.getName().toLowerCase());
    }

    public boolean hasInvite(UUID playerUuid, Faction faction) {
        if (faction == null) return false;
        Set<String> invites = playerInvites.get(playerUuid);
        return invites != null && invites.contains(faction.getName().toLowerCase());
    }

    public void clearInvite(UUID playerUuid, Faction faction) {
        if (faction == null) return;
        Set<String> invites = playerInvites.get(playerUuid);
        if (invites != null) {
            invites.remove(faction.getName().toLowerCase());
            if (invites.isEmpty()) {
                playerInvites.remove(playerUuid);
            }
        }
    }

    public void inviteAlly(Faction sender, Faction target) {
        allyInvites.computeIfAbsent(target.getName().toLowerCase(), k -> new HashSet<>()).add(sender.getName().toLowerCase());
    }

    public boolean hasAllyInvite(Faction sender, Faction target) {
        Set<String> invites = allyInvites.get(target.getName().toLowerCase());
        return invites != null && invites.contains(sender.getName().toLowerCase());
    }

    public void clearAllyInvite(Faction sender, Faction target) {
        Set<String> invites = allyInvites.get(target.getName().toLowerCase());
        if (invites != null) {
            invites.remove(sender.getName().toLowerCase());
        }
    }

    public void createAlliance(Faction f1, Faction f2) {
        f1.addAlly(f2.getName());
        f2.addAlly(f1.getName());
        clearAllyInvite(f1, f2);
        clearAllyInvite(f2, f1);
        save();
    }

    public void breakAlliance(Faction f1, Faction f2) {
        f1.removeAlly(f2.getName());
        f2.removeAlly(f1.getName());
        save();
    }

    public void addMember(Faction faction, UUID playerUuid) {
        if (faction == null) return;
        faction.addMember(playerUuid, Rank.CZLONEK);
        factionOfPlayer.put(playerUuid, faction.getName().toLowerCase());
        save();
    }

    public void removeMember(Faction faction, UUID playerUuid) {
        if (faction == null) return;
        faction.getMembers().remove(playerUuid);
        factionOfPlayer.remove(playerUuid);
        save();
    }

    public Collection<Faction> getAll() {
        return factionsByName.values();
    }

    public void load() {
        if (dataFile == null) {
            dataFile = new File(plugin.getDataFolder(), "factions.yml");
        }
        if (!dataFile.exists()) return;

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : yaml.getKeys(false)) {
            String name = yaml.getString(key + ".name");
            String leaderStr = yaml.getString(key + ".leader");
            String world = yaml.getString(key + ".world");
            int x = yaml.getInt(key + ".x");
            int y = yaml.getInt(key + ".y");
            int z = yaml.getInt(key + ".z");
            int level = yaml.getInt(key + ".level", 1);
            int lives = yaml.getInt(key + ".lives", level);

            World w = Bukkit.getWorld(world != null ? world : "world");
            if (w == null) continue;

            Location heart = new Location(w, x, y, z);
            UUID leader = UUID.fromString(leaderStr);

            Faction f = new Faction(name, leader, heart);
            f.setLevel(level);
            f.setCurrentHeartLives(lives);

            if (yaml.contains(key + ".allies")) {
                List<String> allies = yaml.getStringList(key + ".allies");
                for (String ally : allies) {
                    f.addAlly(ally);
                }
            }

            if (yaml.contains(key + ".home.world")) {
                f.setHomeRaw(
                        yaml.getString(key + ".home.world"),
                        yaml.getDouble(key + ".home.x"),
                        yaml.getDouble(key + ".home.y"),
                        yaml.getDouble(key + ".home.z"),
                        (float) yaml.getDouble(key + ".home.yaw"),
                        (float) yaml.getDouble(key + ".home.pitch")
                );
            }

            List<Map<?, ?>> members = yaml.getMapList(key + ".members");
            for (Map<?, ?> m : members) {
                UUID uuid = UUID.fromString((String) m.get("uuid"));
                Rank rank = Rank.valueOf((String) m.get("rank"));
                f.addMember(uuid, rank);
                factionOfPlayer.put(uuid, name.toLowerCase());
            }

            factionsByName.put(name.toLowerCase(), f);
        }
    }

    public void save() {
        if (dataFile == null) {
            dataFile = new File(plugin.getDataFolder(), "factions.yml");
        }
        YamlConfiguration yaml = new YamlConfiguration();

        for (Faction f : factionsByName.values()) {
            String path = f.getName().toLowerCase() + ".";
            yaml.set(path + "name", f.getName());
            yaml.set(path + "leader", f.getLeader().toString());
            yaml.set(path + "world", f.getWorldName());
            Location h = f.getHeartLocation();
            yaml.set(path + "x", h != null ? h.getBlockX() : 0);
            yaml.set(path + "y", h != null ? h.getBlockY() : 0);
            yaml.set(path + "z", h != null ? h.getBlockZ() : 0);
            yaml.set(path + "level", f.getLevel());
            yaml.set(path + "lives", f.getCurrentHeartLives());
            yaml.set(path + "allies", new ArrayList<>(f.getAllies()));

            Location home = f.getHomeLocation();
            if (home != null && home.getWorld() != null) {
                yaml.set(path + "home.world", home.getWorld().getName());
                yaml.set(path + "home.x", home.getX());
                yaml.set(path + "home.y", home.getY());
                yaml.set(path + "home.z", home.getZ());
                yaml.set(path + "home.yaw", home.getYaw());
                yaml.set(path + "home.pitch", home.getPitch());
            }

            List<Map<String, Object>> memberList = new ArrayList<>();
            for (Map.Entry<UUID, Rank> entry : f.getMembers().entrySet()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("uuid", entry.getKey().toString());
                m.put("rank", entry.getValue().name());
                memberList.add(m);
            }
            yaml.set(path + "members", memberList);
        }

        try {
            yaml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Blad zapisu factions.yml: " + e.getMessage());
        }
    }

    public boolean wouldOverlapOnUpgrade(Faction faction) {
        int nextRadius = radiusForLevel(faction.getLevel() + 1);
        int cx = faction.getHeartChunkX();
        int cz = faction.getHeartChunkZ();

        for (Faction other : getAll()) {
            if (other.equals(faction)) continue;
            if (!other.getWorldName().equals(faction.getWorldName())) continue;

            int otherRadius = radiusForLevel(other.getLevel());
            int ocx = other.getHeartChunkX();
            int ocz = other.getHeartChunkZ();

            if (Math.abs(cx - ocx) <= (nextRadius + otherRadius) && Math.abs(cz - ocz) <= (nextRadius + otherRadius)) {
                return true;
            }
        }
        return false;
    }
}