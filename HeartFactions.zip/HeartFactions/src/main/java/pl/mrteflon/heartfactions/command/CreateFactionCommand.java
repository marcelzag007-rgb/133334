package pl.mrteflon.heartfactions.command;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.manager.HeartStructure;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.util.Msg;

public class CreateFactionCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public CreateFactionCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Komenda tylko dla graczy.");
            return true;
        }

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /stworz <nazwa_frakcji>");
            return true;
        }

        String name = args[0];
        FactionManager manager = plugin.getFactionManager();

        if (manager.getByPlayer(player.getUniqueId()) != null) {
            Msg.send(plugin, player, "&cNależysz już do innej frakcji!");
            return true;
        }

        if (manager.existsByName(name)) {
            Msg.send(plugin, player, "&cFrakcja o takiej nazwie już istnieje!");
            return true;
        }

        Location heartLoc = player.getLocation();

        Faction faction = manager.createFaction(name, player.getUniqueId(), heartLoc);
        HeartStructure.generateStructure(heartLoc, 1);

        Msg.send(plugin, player, "&aZałożono frakcję &f" + faction.getName() + "&a!");
        Msg.send(plugin, player, "&eKryształ Serca zapulsował dokładnie w miejscu, w którym stoisz, otoczony obudową z obsydianu.");
        return true;
    }
}