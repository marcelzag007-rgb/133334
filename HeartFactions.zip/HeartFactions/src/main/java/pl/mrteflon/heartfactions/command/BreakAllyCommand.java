package pl.mrteflon.heartfactions.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import pl.mrteflon.heartfactions.HeartFactionsPlugin;
import pl.mrteflon.heartfactions.manager.FactionManager;
import pl.mrteflon.heartfactions.model.Faction;
import pl.mrteflon.heartfactions.model.Rank;
import pl.mrteflon.heartfactions.util.Msg;

public class BreakAllyCommand implements CommandExecutor {

    private final HeartFactionsPlugin plugin;

    public BreakAllyCommand(HeartFactionsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length < 1) {
            Msg.send(plugin, player, "&cUżycie: /rozlam <nazwa_frakcji>");
            return true;
        }

        FactionManager manager = plugin.getFactionManager();
        Faction myFaction = manager.getByPlayer(player.getUniqueId());

        if (myFaction == null) {
            Msg.send(plugin, player, "&cNie należysz do żadnej frakcji.");
            return true;
        }

        if (myFaction.getRank(player.getUniqueId()) != Rank.LIDER) {
            Msg.send(plugin, player, "&cTylko Lider może zrywać sojusze.");
            return true;
        }

        Faction targetFaction = manager.getByName(args[0]);
        if (targetFaction == null) {
            Msg.send(plugin, player, "&cNie znaleziono frakcji &e" + args[0]);
            return true;
        }

        if (!myFaction.isAlly(targetFaction.getName())) {
            Msg.send(plugin, player, "&cTwoja frakcja nie posiada sojuszu z &e" + targetFaction.getName());
            return true;
        }

        manager.breakAlliance(myFaction, targetFaction);

        Bukkit.broadcastMessage("§8[§bFrakcje§8] §cFrakcja §l" + myFaction.getName() + " §czerwała sojusz z frakcją §l" + targetFaction.getName() + "§c!");

        return true;
    }
}