package pl.mrteflon.heartfactions.util;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class HeartStructure {

    /**
     * Tworzy obudowę wokół Serca (Kryształu) w zależności od poziomu frakcji.
     */
    public static void generateStructure(Location center, int level) {
        if (center == null || center.getWorld() == null) return;

        Location base = center.getBlock().getLocation();

        // Podstawa pod Kryształ (Obsydian)
        base.clone().add(0, -1, 0).getBlock().setType(Material.OBSIDIAN);

        // Dodatkowa obudowa w zależności od poziomu
        if (level >= 2) {
            base.clone().add(1, 0, 0).getBlock().setType(Material.OBSIDIAN);
            base.clone().add(-1, 0, 0).getBlock().setType(Material.OBSIDIAN);
            base.clone().add(0, 0, 1).getBlock().setType(Material.OBSIDIAN);
            base.clone().add(0, 0, -1).getBlock().setType(Material.OBSIDIAN);
        }

        if (level >= 3) {
            base.clone().add(1, 1, 0).getBlock().setType(Material.CRYING_OBSIDIAN);
            base.clone().add(-1, 1, 0).getBlock().setType(Material.CRYING_OBSIDIAN);
            base.clone().add(0, 1, 1).getBlock().setType(Material.CRYING_OBSIDIAN);
            base.clone().add(0, 1, -1).getBlock().setType(Material.CRYING_OBSIDIAN);
        }
    }

    /**
     * Usuwa obudowę Serca po jego zniszczeniu.
     */
    public static void removeStructure(Location center) {
        if (center == null || center.getWorld() == null) return;

        Location base = center.getBlock().getLocation();

        int radius = 2;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -1; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Block b = base.clone().add(x, y, z).getBlock();
                    if (b.getType() == Material.OBSIDIAN || b.getType() == Material.CRYING_OBSIDIAN) {
                        b.setType(Material.AIR);
                    }
                }
            }
        }
    }
}