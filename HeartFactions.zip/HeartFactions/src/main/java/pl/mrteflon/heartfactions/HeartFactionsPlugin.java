package pl.mrteflon.heartfactions;

import org.bukkit.plugin.java.JavaPlugin;
import pl.mrteflon.heartfactions.command.*;
import pl.mrteflon.heartfactions.listener.ProtectionListener;
import pl.mrteflon.heartfactions.manager.FactionManager;

public class HeartFactionsPlugin extends JavaPlugin {

    private FactionManager factionManager;

    @Override
    public void onEnable() {
        this.factionManager = new FactionManager(this);
        this.factionManager.load();

        // Rejestracja komend
        if (getCommand("stworz") != null) getCommand("stworz").setExecutor(new CreateFactionCommand(this));
        if (getCommand("sojusz") != null) getCommand("sojusz").setExecutor(new AllyCommand(this));
        if (getCommand("zerwij") != null) getCommand("zerwij").setExecutor(new BreakAllyCommand(this));
        if (getCommand("zaakceptuj") != null) getCommand("zaakceptuj").setExecutor(new AcceptCommand(this));
        if (getCommand("odrzuc") != null) getCommand("odrzuc").setExecutor(new DenyCommand(this));
        if (getCommand("zapros") != null) getCommand("zapros").setExecutor(new InviteCommand(this));
        if (getCommand("wyrzuc") != null) getCommand("wyrzuc").setExecutor(new KickCommand(this));
        if (getCommand("opusc") != null) getCommand("opusc").setExecutor(new LeaveCommand(this));
        if (getCommand("rozwiaz") != null) getCommand("rozwiaz").setExecutor(new DisbandCommand(this));
        if (getCommand("info") != null) getCommand("info").setExecutor(new InfoCommand(this));
        if (getCommand("lista") != null) getCommand("lista").setExecutor(new ListCommand(this));
        if (getCommand("awans") != null) getCommand("awans").setExecutor(new PromoCommand(this));
        if (getCommand("degrad") != null) getCommand("degrad").setExecutor(new DemoteCommand(this));
        if (getCommand("dom") != null) getCommand("dom").setExecutor(new HomeCommand(this));
        if (getCommand("setdom") != null) getCommand("setdom").setExecutor(new SetHomeCommand(this));
        if (getCommand("ulepsz") != null) getCommand("ulepsz").setExecutor(new HeartUpgradeCommand(this));
        if (getCommand("granice") != null) getCommand("granice").setExecutor(new BorderCommand(this));

        // Rejestracja listenera ochrony i C4
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);

        getLogger().info("HeartFactions zostal wlaczony!");
    }

    @Override
    public void onDisable() {
        if (factionManager != null) {
            factionManager.save();
        }
        getLogger().info("HeartFactions zostal wylaczony!");
    }

    public FactionManager getFactionManager() {
        return factionManager;
    }
}