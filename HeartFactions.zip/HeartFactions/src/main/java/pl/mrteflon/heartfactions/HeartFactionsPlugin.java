package pl.mrteflon.heartfactions;

import org.bukkit.plugin.java.JavaPlugin;
import pl.mrteflon.heartfactions.command.*;
import pl.mrteflon.heartfactions.listener.ProtectionListener;
import pl.mrteflon.heartfactions.manager.FactionManager;

public class HeartFactionsPlugin extends JavaPlugin {

    private FactionManager factionManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        factionManager = new FactionManager(this);
        factionManager.load();

        if (getCommand("stworz") != null) getCommand("stworz").setExecutor(new CreateFactionCommand(this));
        if (getCommand("heartupgrade") != null) getCommand("heartupgrade").setExecutor(new HeartUpgradeCommand(this));
        if (getCommand("granica") != null) getCommand("granica").setExecutor(new BorderCommand(this));
        if (getCommand("promo") != null) getCommand("promo").setExecutor(new PromoCommand(this));
        if (getCommand("demote") != null) getCommand("demote").setExecutor(new DemoteCommand(this));
        if (getCommand("flist") != null) getCommand("flist").setExecutor(new ListCommand(this));
        if (getCommand("zapros") != null) getCommand("zapros").setExecutor(new InviteCommand(this));
        if (getCommand("dolacz") != null) getCommand("dolacz").setExecutor(new AcceptCommand(this));
        if (getCommand("odrzuc") != null) getCommand("odrzuc").setExecutor(new DenyCommand(this));
        if (getCommand("wyrzuc") != null) getCommand("wyrzuc").setExecutor(new KickCommand(this));
        if (getCommand("opusc") != null) getCommand("opusc").setExecutor(new LeaveCommand(this));
        if (getCommand("rozwiaz") != null) getCommand("rozwiaz").setExecutor(new DisbandCommand(this));
        if (getCommand("finfo") != null) getCommand("finfo").setExecutor(new InfoCommand(this));
        if (getCommand("frakcje") != null) getCommand("frakcje").setExecutor(new FactionsHelpCommand(this));
        if (getCommand("domfrakcji") != null) getCommand("domfrakcji").setExecutor(new HomeCommand(this));
        if (getCommand("ustawdomfrakcji") != null) getCommand("ustawdomfrakcji").setExecutor(new SetHomeCommand(this));

        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);

        getLogger().info("Plugin Frakcje został aktywowany!");
    }

    @Override
    public void onDisable() {
        if (factionManager != null) {
            factionManager.save();
        }
    }

    public FactionManager getFactionManager() {
        return factionManager;
    }
}